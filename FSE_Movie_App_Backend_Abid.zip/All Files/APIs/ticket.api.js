const exp = require('express')
const ticketApp = exp.Router()
const { bookTicket, getBookedTickets } = require('../controllers/ticket.controller')
const {verifyToken} = require('../utils/auth')
ticketApp.get('/gettickets/:id',verifyToken,getBookedTickets)
ticketApp.post('/bookticket',verifyToken,bookTicket)

module.exports=ticketApp
