export class Movie {
    constructor(
        public title: any,
        public img: any,
        public theatre: string,
        public price:Number,
        public totaltickets: Number,
        public availabletickets: Number
    ) { }
}
