import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { of, throwError } from 'rxjs';
import { UserregisterService } from '../services/userregister.service';

import { ResetpasswordComponent } from './resetpassword.component';

describe('ResetpasswordComponent', () => {
  let component: ResetpasswordComponent;
  let logindata=UserregisterService;
  let fixture: ComponentFixture<ResetpasswordComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ResetpasswordComponent],
      imports :[HttpClientTestingModule, FormsModule, ReactiveFormsModule]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ResetpasswordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call reset error..', ()=>{
    let service = fixture.debugElement.injector.get(logindata);
    spyOn(service, 'resetPassword').and.returnValue(throwError({status:422}))
     
    let spy =spyOn(component, 'reset').and.callThrough();
    component.reset();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  })

  it('should call reset error..', ()=>{
    let service = fixture.debugElement.injector.get(logindata);
    spyOn(service, 'resetPassword').and.callFake(()=>{
        return of({
          message:'password reset succesfully'
        })
      })
    let spy =spyOn(component, 'reset').and.callThrough();
    component.reset();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  })
});
