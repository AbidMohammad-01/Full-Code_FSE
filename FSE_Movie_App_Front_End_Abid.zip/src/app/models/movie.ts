export class Movie {
    constructor(
        public title: string,
        public img: string,
        public theatre: string,
        public price:Number,
        public totaltickets: Number,
        public availabletickets: Number
    ) { }
}
